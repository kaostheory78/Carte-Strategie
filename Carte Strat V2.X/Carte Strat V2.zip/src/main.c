/* 
 * File:   main.c
 * Author: Quentin
 *
 * Created on 22 octobre 2014, 23:55
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv)
{

    return (EXIT_SUCCESS);
}

