/**********************************************************************
* � 2005 Microchip Technology Inc.
*
* FileName:        adcDrv1.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC33Exxxx/PIC24Exxxx
* Compiler:        MPLAB� C30 v3.30 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip's
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP'S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Settu D 			07/09/06  First release of source file
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Sorin M 			07/01/10  Updated for dsPIC33E
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Srikar D			04/27/11  Updated for dsPIC33E / PIC24E
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*
* ADDITIONAL NOTES:
**********************************************************************/

#if defined(__dsPIC33E__)
#include "p33exxxx.h"
#elif defined(__PIC24E__)
#include "p24exxxx.h"
#endif

#include "adcDrv1.h"
#include "tglPin.h"

// Define Message Buffer Length for ECAN1/ECAN2
#define  MAX_CHNUM	 			5		// Highest Analog input number enabled for alternate sampling
#define  SAMP_BUFF_SIZE	 		16		// Size of the input buffer per analog input

// Number of locations for ADC buffer = 2 (AN4 and AN5) x 16 = 32 words
// Align the buffer to 32words or 64 bytes. This is needed for peripheral indirect mode

#ifdef _HAS_DMA_
__eds__ int BufferA[MAX_CHNUM+1][SAMP_BUFF_SIZE] __attribute__((eds,space(dma),aligned(64)));
__eds__ int BufferB[MAX_CHNUM+1][SAMP_BUFF_SIZE] __attribute__((eds,space(dma),aligned(64)));
#else
int BufferA[MAX_CHNUM+1][SAMP_BUFF_SIZE] __attribute__((space(xmemory)));
int BufferB[MAX_CHNUM+1][SAMP_BUFF_SIZE] __attribute__((space(xmemory)));

#endif



void ProcessADCSamples(__eds__ int * AdcBuffer);



/*=============================================================================
ADC Initialisation for Channel Scan 
=============================================================================*/
void initAdc1(void)
{
		AD1CON1bits.FORM   = 3;		// Data Output Format: Signed Fraction (Q15 format)
		AD1CON1bits.SSRC   = 2;		// Sample Clock Source: GP Timer starts conversion
		AD1CON1bits.ASAM   = 1;		// ADC Sample Control: Sampling begins immediately after conversion
		AD1CON1bits.AD12B  = 0;		// 10-bit ADC operation
	

		AD1CON2bits.ALTS=1;			// Alternate Input Sample Mode Select Bit
		AD1CON2bits.CHPS  = 0;		// Converts CH0

		AD1CON3bits.ADRC = 0;		// ADC Clock is derived from Systems Clock
		AD1CON3bits.ADCS = 63;		// ADC Conversion Clock Tad=Tcy*(ADCS+1)= (1/40M)*64 = 1.6us (625Khz)
									// ADC Conversion Time for 10-bit Tc=12*Tab = 19.2us	

		AD1CON1bits.ADDMABM = 0; 	// DMA buffers are built in scatter/gather mode
		AD1CON2bits.SMPI    = 1;	// SMPI Must be programmed to 1 for this case
		AD1CON4bits.DMABL   = 4;	// Each buffer contains 16 words
		AD1CON4bits.ADDMAEN = 1;	// Conversion results stored in ADCxBUF0 register


        //AD1CHS0: A/D Input Select Register
        AD1CHS0bits.CH0SA=4;		// MUXA +ve input selection (AIN4) for CH0
		AD1CHS0bits.CH0NA=0;		// MUXA -ve input selection (Vref-) for CH0

        AD1CHS0bits.CH0SB=5;		// MUXB +ve input selection (AIN5) for CH0
		AD1CHS0bits.CH0NB=0;		// MUXB -ve input selection (Vref-) for CH0
				
        //AD1PCFGH/AD1PCFGL: Port Configuration Register
//		AD1PCFGL=0xFFFF;
//		AD1PCFGH=0xFFFF;
//      AD1PCFGLbits.PCFG4 = 0;		// AN4 as Analog Input
//      AD1PCFGLbits.PCFG5 = 0;		// AN5 as Analog Input		
        
        IFS0bits.AD1IF = 0;			// Clear the A/D interrupt flag bit
        IEC0bits.AD1IE = 0;			// Do Not Enable A/D interrupt 
        AD1CON1bits.ADON = 1;		// Turn on the A/D converter	

        tglPinInit();

}

/*=============================================================================  
Timer 3 is setup to time-out every 125 microseconds (8Khz Rate). As a result, the module 
will stop sampling and trigger a conversion on every Timer3 time-out, i.e., Ts=125us. 
=============================================================================*/
void initTmr3() 
{
        TMR3 = 0x0000;
        PR3 = 4999;
        IFS0bits.T3IF = 0;
        IEC0bits.T3IE = 0;

        //Start Timer 3
        T3CONbits.TON = 1;

}


// DMA0 configuration
// Direction: Read from peripheral address 0-x300 (ADC1BUF0) and write to DMA RAM 
// AMODE: Peripheral Indirect Addressing Mode
// MODE: Continuous, Ping-Pong Mode
// IRQ: ADC Interrupt
// ADC stores results stored alternatively between DMA_BASE[0]/DMA_BASE[16] on every 16th DMA request 

void initDma0(void)
{
	DMA0CONbits.AMODE = 2;			// Configure DMA for Peripheral indirect mode
	DMA0CONbits.MODE  = 2;			// Configure DMA for Continuous Ping-Pong mode
	
	DMA0PAD=(int)&ADC1BUF0;
	DMA0CNT = (SAMP_BUFF_SIZE*2)-1;					

	DMA0REQ=13;
	#ifdef _HAS_DMA_
	DMA0STAL = __builtin_dmaoffset(&BufferA);
	DMA0STAH = __builtin_dmapage(&BufferA);

	DMA0STBL = __builtin_dmaoffset(&BufferB);
	DMA0STBH = __builtin_dmapage(&BufferB);
	#else
	DMA0STAL = (unsigned int)&BufferA;
	DMA0STAH = (unsigned int)&BufferA;

	DMA0STBL = (unsigned int)&BufferB;
	DMA0STBH = (unsigned int)&BufferB;

	#endif
	

	IFS0bits.DMA0IF = 0;			//Clear the DMA interrupt flag bit
    IEC0bits.DMA0IE = 1;			//Set the DMA interrupt enable bit

	DMA0CONbits.CHEN=1;

}


/*=============================================================================
_DMA0Interrupt(): ISR name is chosen from the device linker script.
=============================================================================*/

unsigned int DmaBuffer = 0;

void __attribute__((interrupt, auto_psv)) _DMA0Interrupt(void)
{
   		
		if(DmaBuffer==0) {			
			ProcessADCSamples(&BufferA[4][0]);
			ProcessADCSamples(&BufferA[5][0]);

		} else {					
			ProcessADCSamples(&BufferB[4][0]);
			ProcessADCSamples(&BufferB[5][0]);
		}

		DmaBuffer ^= 1;

	
		tglPin();					// Toggle PORTA, BIT6	
        IFS0bits.DMA0IF = 0;		//Clear the DMA0 Interrupt Flag
}




void ProcessADCSamples(__eds__ int * AdcBuffer)
{
	/* Do something with ADC Samples */
}






