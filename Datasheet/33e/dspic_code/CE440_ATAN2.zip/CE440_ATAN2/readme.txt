For a range of input angles calculate the x and y fractional
values corresponding to this angle. Then calculate the
return value from the C standard atan2 function and also
from the modifiy atan2CORDIC routine, print the result and error