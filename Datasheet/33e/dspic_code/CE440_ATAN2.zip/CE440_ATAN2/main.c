/***********************************************************************
 *                                                                     * 
 *    Author:         Darren Wenn                                      *
 *    Company:        Microchip Ltd                                    * 
 *    Filename:       main.c                                           *
 *    Date:           27/10/2006                                       *
 *    File Version:   1.00                                             *
 *    Other Files Required: atan2CORDIC.s			                   *
 *                                                                     *
 ***********************************************************************
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip's
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP'S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
* REVISION HISTORY:
************************************************************************/

#if defined(__dsPIC33E__)
#include "p33exxxx.h"
#elif defined(__PIC24E__)
#include "p24exxxx.h"
#endif

#include <stdio.h>
#include <math.h>
#include <dsp.h>

// angular increment in radians
#define DELTA_ANGLE (0.01)

// definition of assembly function in atan2CORDIC.s
fractional atan2CORDIC(fractional y, fractional x);

///////////////////////////////////////////////////////////////////
//
//  main() test rig harness for the assembly CORDIC routine
//  For a range of input angles calculate the x and y fractional
//	values corresponding to this angle. Then calculate the
//	return value from the C standard atan2 function and also
//	from the modifiy atan2CORDIC routine, print the result and error
//
///////////////////////////////////////////////////////////////////

int main(void)
{
	double x, y;
	double cFunc;
	double theta;
	double theta1;
	double err;
	fractional fx, fy;
	fractional fRes;
	
	printf("Theta, x, y, atan2(y x), CORDIC, Error\r");
	for(theta = -PI; theta < PI; theta += DELTA_ANGLE) {
		printf("%f, ", theta);
		// calculate the x and y values for this angle		
		x = cos(theta);	
		y = sin(theta);
		printf("%f, %f, ", x, y);
		
		// calculate the angle using the library routine
		cFunc = atan2(y, x);
		printf("%f, ", cFunc);
		
		// atan2CORDIC only accepts dsPIC fractionals
		fx = Float2Fract(x);
		fy = Float2Fract(y);
		fRes = atan2CORDIC(fy, fx);
		// the return value is a dsPIC fractional from -1.0 to 0.9999
		// representing the range -PI to PI, so scale the result
		theta1 = Fract2Float(fRes);
		theta1 *= PI;
		printf("%f, ", theta1);
		
		// calculate the error in degrees
		err = (180.0 / PI) * (cFunc - theta1);
		printf("%f\r", err);
	}

	return 0;	
}
